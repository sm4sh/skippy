(function() {
	var isEnabled = localStorage.getItem('skipper_enabled');

	var observer = new MutationObserver(function(mutations) {
		mutations.forEach(function(mutation) {
			if (isEnabled === "false" || mutation.addedNodes.length === 0 || mutation.addedNodes[0].className === undefined || !mutation.addedNodes[0].className.toString().match(/ptrack-container/)) {
				return;
			}
			var skipCredits = document.getElementsByClassName('skip-credits');
			var postPlay = document.getElementsByClassName('postplay-still-container');
			var watchNext = document.getElementsByClassName('WatchNext-still-container');

			if (skipCredits.length !== 0) {
				skipCredits[0].firstElementChild.click();
			} else if (postPlay.length !== 0) {
				postPlay[0].click();
			} else if (watchNext.length !== 0) {
				watchNext[0].click();
			}
		});
	});
	window.setInterval(function () {
		isEnabled = localStorage.getItem('skipper_enabled');
	}, 5000);
	observer.observe(document.querySelector('body'), {childList: true, subtree: true});
})();
