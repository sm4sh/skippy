(function () {
	console.log('out');
	browser.browserAction.onClicked.addListener(function() {
		console.log('in');
		var isEnabled = localStorage.getItem('skipper_enabled') || "true";
		isEnabled = isEnabled === "true" ? "false" : "true";
		localStorage.setItem('skpper_enabled', isEnabled);
		var iconPath = isEnabled === "true" ? "icons/netflix_32.png" : "icons/netflix_32_disabled.png";
		browser.browserAction.setIcon({ path: iconPath });
	});
})();
